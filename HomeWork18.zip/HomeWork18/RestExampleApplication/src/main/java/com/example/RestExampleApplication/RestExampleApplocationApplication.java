package com.example.RestExampleApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestExampleApplocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestExampleApplocationApplication.class, args);
	}

}
